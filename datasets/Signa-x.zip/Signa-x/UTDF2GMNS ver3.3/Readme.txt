* save your UTDF export data as "UTDF8.csv" and replace the default csv file in this folder
* open "UTDF2GMNS.xlsm" and run the program under the "Control" tab (click on the run button)
* once the program finish running, it will save GMNS csv files, as well as a Sigma-X file for each signalized node

*this version reads existing UTDF phasing, geometry and volume data; computes cycle and splits based on the given inputs; 
optimizes cycle for min total intersection delay